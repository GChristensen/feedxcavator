;; One headline with today's errors and warnings from the log, or none.

(import feedxcavator.models [LogEntry])

(defextractor feedxcavator-health-extractor [feed]
  (setv entries (list (.order-by (.filter LogEntry.objects
                                          :timestamp__gt (midnight-timestamp)
                                          :level__in ["error" "warning"])
                                 "id")))
  (if entries
      [{"link" ""
        "title" "Health report"
        "summary" (+ "Log level: <a href='" (:source feed) "'>"
                     (if (any (gfor e entries (= e.level "error"))) "errors" "warnings")
                     "</a><br><br>"
                     (.join "<hr>" (gfor e entries
                                         (+ "<div style='white-space: pre;'>" (html-sanitize e.message) "</div>"))))}]
      []))
