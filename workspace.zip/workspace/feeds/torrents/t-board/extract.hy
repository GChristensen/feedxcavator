;; T-Board: merges the stored output of the torrent feeds in `params` into one JSON document for the
;; T-Board extension, read through the `t-board` handler. The feed itself has no headlines.

(import itertools [groupby])

(defextractor t-board-extractor [feed]
  (setv headlines [])
  (for [suffix (or (:params feed) [])]
    (setv source (find-feed suffix)
          stored (when source (fetch-feed-output source))
          items (if stored (json.loads (:output stored)) []))
    (when (= suffix "pornolab-egames")
      (setv items (lfor h items
                        (assoc h "category" "games" "feed" "e-games" "group" "E-Games"
                                 "item_id" (+ "internal:" (md5 (:link h)))))))
    (.extend headlines items))
  (setv headlines (filter-history! "t-board" headlines)
        groups (lfor [_ group] (groupby headlines (fn [h] (:feed h))) (list group)))
  (store-object! "t-board" (lfor group groups (lfor h group (clojure-keys h))))
  (store-object! "t-board-finished-at" (get-day-of-month))
  [])
