(defextractor t-board-reminder-extractor [feed]
  [{"title" "Open T-Board"
    "guid" (generate-uuid)
    "link" (redirect-url (+ "ext+jt://main#" (generate-uuid)))}])
