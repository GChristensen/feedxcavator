;; kinozal.tv front pages 0-10 for T-Board. Each release is a pair of elements: the title and the body.

(setv KINOZAL "http://kinozal.tv")

(defn first-in [elements selector]
  "The first match of a selector in any of the elements."
  (next (gfor el elements :setv m (q1 el selector) :if (is-not m None) m) None))

(defn kinozal-headline [pair]
  (setv title (text (first-in pair ".tp1_title a"))
        link (+ KINOZAL (or (attr (first-in pair ".tp1_body a") "href") ""))
        image (or (attr (first-in pair ".tp1_body a img") "src") ""))
  {"title" title
   "link" link
   "image" (if (.startswith image "/") (+ KINOZAL image) image)
   "summary" (outer-html (first-in pair ".tp1_body .tp1_desc"))
   "feed" "kinozal"
   "group" ""
   "size" (text (first-in pair ".tp1_body .tp1_desc2"))
   "youtube" ""
   "item_id" (+ "internal:" (md5 link))
   "category" "movies"})

(defn release-name [h]
  ;; the title before the first slash, without a "(... серии ...)" note
  (.strip (re.sub r"\([^)]*серии[^)]*\)" "" (get (.split (or (:title h) "") "/") 0))))

(defextractor kinozal-extractor [feed]
  (setv headlines
        (lfor n (range 11)
              :setv html (fetch-url (+ KINOZAL "/?page=" (str n)) :as "html")
              :setv children (if html (list (q html ".content .tp1_border > *")) [])
              i (range 0 (- (len children) 1) 2)
              (kinozal-headline [(get children i) (get children (+ i 1))])))
  (distinct-by release-name headlines))
