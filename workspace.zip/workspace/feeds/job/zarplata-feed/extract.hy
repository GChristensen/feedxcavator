;; zarplata.ru (an hh.ru site) vacancies, `max-pages` pages from `start-page`.

(import random)

(setv JOB-BOARD-HEADERS {"User-Agent" "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                         "Accept-Language" "ru-RU,ru;q=0.9,en-US;q=0.8"})

(defn qa-text [node name]
  (text ($1 node (+ "[data-qa=\"" name "\"]"))))

(defn vacancy->headline [item source]
  (setv title (qa-text item "serp-item__title-text")
        link (q1 item "[data-qa=\"serp-item__title\"]::attr(href)")
        employer (qa-text item "vacancy-serp__vacancy-employer-text")
        summary (.join "<br/><br/>" (lfor s [(qa-text item "vacancy-serp__vacancy_snippet_responsibility")
                                              (qa-text item "vacancy-serp__vacancy_snippet_requirement")]
                                           :if s
                                           s)))
  (when (and title link)
    {"title" (html-unescape (if employer (+ title " [" employer "]") title))
     "link" (fix-relative-url link source)
     "summary" summary}))

(defn job-board-headlines [feed]
  (setv source (:source feed)
        start-page (int (or (param feed "start-page") 1))
        max-pages (int (or (param feed "max-pages") 10))
        results [])
  (for [page (range start-page (+ start-page max-pages))]
    (setv doc (log-fetch-errors (fetch-url (+ source "&page=" (str page)) :as "html" :timeout 20000
                                           :follow-redirects True :headers JOB-BOARD-HEADERS))
          items ($ doc "article[data-qa=\"vacancy-serp__vacancy\"]"))
    (when (not items)
      (break))
    (.extend results (keep (fn [item] (vacancy->headline item source)) items))
    (time.sleep (+ 2 (* 3 (random.random)))))
  results)

(defextractor zarplata-extractor [feed]
  (job-board-headlines feed))
