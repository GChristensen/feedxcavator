(defextractor hh-extractor [feed]
  (crawl-json (+ "hh/crawl/" (str (param feed "max-pages")) "/" (str (param feed "url-suffix")))))
