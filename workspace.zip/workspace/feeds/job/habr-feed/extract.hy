;; career.habr.com vacancies, `max-pages` pages from `start-page`.

(import random)

(setv JOB-BOARD-HEADERS {"User-Agent" "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                         "Accept-Language" "ru-RU,ru;q=0.9,en-US;q=0.8"})

(defn chip-text [node selector]
  (text ($1 node selector)))

(defn habr-card->headline [card source]
  (setv title (chip-text card "a.vacancy-card__title-link")
        link (q1 card "a.vacancy-card__title-link::attr(href)")
        company (chip-text card "div.vacancy-card__company a")
        ;; two exclusive salary layouts: a plain range, or a placeholder next to a market-rate tooltip
        salary (or (chip-text card "div.basic-salary") (chip-text card "h4.predicted-salary__title"))
        ;; the grade chip is the only turquoise one; format and location chips are gray
        grade (chip-text card "div.basic-chip.basic-chip--color-ui-turquoise span.chip-with-icon__text")
        format+loc (lfor t (q card "div.vacancy-meta span.chip-with-icon__text")
                         :setv s (text t)
                         :if (!= s grade)
                         s)
        skills (lfor t (q card ".vacancy-card__skills .basic-chip__text") (text t))
        summary (.join "<br/>" (lfor s [(when grade (+ "Уровень: " grade))
                                        (when salary (+ "Зарплата: " salary))
                                        (when format+loc (.join ", " format+loc))
                                        (when skills (+ "Навыки: " (.join ", " skills)))]
                                     :if s
                                     s)))
  (when (and title link)
    {"id" (attr card "data-vacancy-id")
     "title" (html-unescape (if company (+ title " [" company "]") title))
     "link" (fix-relative-url link source)
     "published" (q1 card "time.basic-date::attr(datetime)")
     "summary" summary}))

(defextractor habr-career-extractor [feed]
  (setv source (:source feed)
        start-page (int (or (param feed "start-page") 1))
        max-pages (int (or (param feed "max-pages") 10))
        results [])
  (for [page (range start-page (+ start-page max-pages))]
    (setv doc (log-fetch-errors (fetch-url (+ source "&page=" (str page)) :as "html" :timeout 20000
                                           :follow-redirects True :headers JOB-BOARD-HEADERS))
          ;; every card, regular, branded or "quick response", has this class
          cards ($ doc "div.vacancy-card"))
    (when (not cards)
      (break))
    (.extend results (keep (fn [card] (habr-card->headline card source)) cards))
    (time.sleep (+ 2 (* 3 (random.random)))))
  results)
