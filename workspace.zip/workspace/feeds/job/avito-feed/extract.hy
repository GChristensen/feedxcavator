(defextractor avito-vacancies-extractor [feed]
  (crawl-json (+ "avito/crawl/20/" (str (param feed "url-suffix")))))
