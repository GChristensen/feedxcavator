(defextractor derek-sivers-books-extractor [feed]
  (setv html (fetch-url (:source feed) :as "html" :retry 3))
  (lfor book ($ html "#booklist li")
        :setv title-link ($1 book "h3 a")
        :setv link (+ "https://sive.rs" (or (attr title-link "href") ""))
        :setv img (attr ($1 book "figure a img") "src")
        {"title" (text title-link)
         "link" link
         "guid" link
         "summary" (text ($1 book "p"))
         "image" (when img (+ "https://sive.rs" img))}))
