(defextractor seangoedecke-extractor [feed]
  (rss-to-headlines "https://www.seangoedecke.com/rss.xml" :http-proxy "default"))
