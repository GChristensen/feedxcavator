(defextractor economist-extractor [feed]
  (crawl-json "economist/extract"))
