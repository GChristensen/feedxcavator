;; echofm.online: the RSS items with the full article, its main image and its author.

(import lxml.html)

(setv ECHO-HOST "https://echofm.online"
      ECHO-NEWS-PATTERN r"(?i)главные\s+.+?\s+новости")

(defn echo-lazy-src [srcset]
  "The URL of the largest image of a srcset."
  (when srcset
    (+ ECHO-HOST (get (.split (get (re.split r" \d+w, " srcset) -1) " ") 0))))

(defn echo-article-html [article]
  "The article with its lazy images loaded."
  (setv root (lxml.html.fragment-fromstring (outer-html article)))
  (for [img (.iter root "img")]
    (when (.get img "srcset")
      (.set img "src" (echo-lazy-src (.get img "srcset")))
      (.set img "style" "")))
  (as-> (lxml.html.tostring root :encoding "unicode") s
        (re.sub r"</?noscript>" "" s)
        (re.sub r"<span[^>]*></span>" "" s)))

(defn echo-expand [h]
  (time.sleep 0.3)
  (setv html (fetch-url (:link h) :as "html"))
  (when (is html None)
    (return h))
  (setv author-img ($1 html "article a[href^=\"/author\"] img[srcset]")
        figure-img ($1 html "article figure img[srcset]")
        image (or (echo-lazy-src (attr figure-img "srcset"))
                  (when author-img (+ ECHO-HOST (attr author-img "src")))))
  (setv article ($1 html "article"))
  (assoc h
         "author" (attr author-img "alt")
         "image" (when image (safe-call (save-image image :proxy "default")))
         "summary" (+ (or (:summary h) "") "𖦹<br><hr><br>" (if article (echo-article-html article) ""))))

(defextractor echofm-rss-extractor [feed]
  (setv headlines
        (lfor item (q (fetch-xml (+ ECHO-HOST "/feed") :retry 3) "item")
              :setv link (xml-text item "link")
              {"title" (xml-text item "title")
               "link" link
               "guid" link
               "summary" (xml-text item "description")
               "category" (xml-text item "category")
               "image_type" "image/jpeg"}))
  (lfor h (map echo-expand headlines)
        :if (not (and (:title h) (re.search ECHO-NEWS-PATTERN (:title h))))
        h))
