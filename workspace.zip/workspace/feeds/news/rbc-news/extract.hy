(defextractor rbc-rss-extractor [feed]
  (lfor item (q (fetch-xml "https://rssexport.rbc.ru/rbcnews/news/30/full.rss" :retry 3) "item")
        :setv link (xml-text item "link")
        {"title" (xml-text item "title")
         "link" link
         "guid" link}))
