;; The Reuters front page in a browser: the stories found by the selectors, without the Markets block,
;; and the cards of the Pictures block.

(setv REUTERS-REMOVE-MARKETS
      "(() => {
  const divider = document.evaluate(
    \"//div[contains(@class, 'divider-container')][.//a[normalize-space(text())='Markets']]\",
    document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (divider) { divider.remove(); return true; }
  return false;
})()")

(setv REUTERS-PICTURE-LINKS
      "(() => {
  const elements = document.evaluate(
    '//div[@data-testid=\"Topic\"][.//h2[contains(text(), \"Pictures\")]]//div[@data-testid=\"MediaStoryCard\"]',
    document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
  const results = [];
  for (let i = 0; i < elements.snapshotLength; i++) {
    const card = elements.snapshotItem(i);
    const heading = card.querySelector('a[data-testid=\"Heading\"]');
    const link = heading ? heading.getAttribute('href') : null;
    const title = heading ? heading.textContent.trim() : null;
    const image = card.querySelector('div[class*=\"media-story-card__image-container\"] img');
    results.push({
      title: '🖼️' + title,
      link: link ? (link.startsWith('http') ? link : 'https://reuters.com' + link) : null,
      image: image ? image.getAttribute('src') : null
    });
  }
  return results;
})()")

(defextractor reuters-extractor [feed]
  (with-browser [b]
    (setv page (.open b (:source feed)))
    (.wait page 5)
    (for [_ (range 16)]
      (.evaluate page "window.scrollBy(0, window.innerHeight)")
      (.wait page 1))
    (.wait page 5)
    (.evaluate page REUTERS-REMOVE-MARKETS)
    (setv headlines [#* (or (.apply-selectors page) []) #* (or (.evaluate page REUTERS-PICTURE-LINKS) [])]))
  (lfor h headlines
        :setv title (.lower (or (:title h) ""))
        :if (not (or (in "podcast" title) (in "coffee" title)))
        (if (:image h)
            (assoc h "summary" (+ (or (:summary h) "") " <img src='" (:image h) "'>"))
            h)))
