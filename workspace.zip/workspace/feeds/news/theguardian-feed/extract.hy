;; The front page of The Guardian: the "news" and "in pictures" sections, each a Primary container
;; with the Secondary containers that follow it.

(setv GUARDIAN-SECTIONS #{"news" "in pictures"}
      GUARDIAN-PRIORITY ["in pictures" "news" "more top stories" "opinion" "more news"])

(defn guardian-groups [doc]
  (setv groups [])
  (for [section (q doc "section[data-container-level]")]
    (setv level (attr section "data-container-level"))
    (cond
      (= level "Primary") (.append groups [section])
      (and (= level "Secondary") groups) (.append (get groups -1) section)))
  groups)

(defn guardian-item [li]
  (setv found (next (gfor a (q li "a") :if (and (attr a "data-link-name") (attr a "aria-label")) a) None))
  (when found
    (setv image (attr ($1 li "img") "src"))
    {"link" (+ "https://theguardian.com" (attr found "href"))
     "title" (attr found "aria-label")
     "image" image
     "summary" (+ "<img src='" (str image) "'>")}))

(defextractor theguardian-extractor [feed]
  (setv doc (fetch-url (:source feed) :as "html" :proxy "default" :headers {"user-agent" CHROME-USERAGENT})
        results (lfor group (guardian-groups doc)
                      :setv section-id (attr (get group 0) "id")
                      :setv cleaned-id (when section-id (.replace section-id "-" " "))
                      :if (in cleaned-id GUARDIAN-SECTIONS)
                      [cleaned-id (lfor section group
                                        li (q section "li")
                                        :setv h (guardian-item li)
                                        :if h
                                        h)])
        ordered (sorted results :key (fn [r] (if (in (get r 0) GUARDIAN-PRIORITY)
                                                 (.index GUARDIAN-PRIORITY (get r 0))
                                                 (len GUARDIAN-PRIORITY)))))
  (lfor [section-id links] ordered
        h links
        (assoc h "title" (+ "[" section-id "] " (str (:title h))))))
