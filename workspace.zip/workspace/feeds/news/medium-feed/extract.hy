;; Followed Medium authors, read by crawlerext; links open through a freedium mirror.

(defextractor medium-extractor [feed]
  (lfor h (crawl-json (+ "medium/crawl/following/2/" (params-path feed)))
        (assoc h "link" (+ "https://freedium-mirror.cfd/" (:link h)))))
