(defextractor local-feeds-extractor [feed]
  (lfor h (rss-to-headlines "https://drugoigorod.ru/feed/")
        (assoc h "title" (+ "[D] " (or (:title h) "")))))
