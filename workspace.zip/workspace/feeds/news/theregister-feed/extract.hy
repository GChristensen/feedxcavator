(defextractor the-register-extractor [feed]
  (lfor h (rss-to-headlines (:source feed))
        (assoc h
               "image" (when (:image h)
                         (forward-url (:image h) "https://www.theregister.com/" :https True :proxy "default"))
               "image_type" "image/jpeg")))
