;; Hacker News and Lobsters in one feed.

(defn rss-items [url tag]
  (lfor item (q (fetch-xml url) "item")
        :setv link (xml-text item "link")
        {"title" (xml-text item "title")
         "link" link
         "guid" link
         "summary" (+ "[" tag "] " (or (xml-text item "description") ""))}))

(defextractor hacker-news-extractor [feed]
  (distinct-by "link" [#* (rss-items "https://news.ycombinator.com/rss" "HN")
                       #* (rss-items "https://lobste.rs/rss" "LS")]))
