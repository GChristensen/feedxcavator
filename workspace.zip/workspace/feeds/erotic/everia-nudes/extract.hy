;; Gallery links open in the JAVBoard gallery viewer (ext+jb-gallery://) through /redirect.
;; The redirect link has a fixed random part, so that a link stays the same across runs.

(defextractor everia-extractor [feed]
  (lfor h (or (parse-html-page feed "https://everia.club") [])
        :if (:link h)
        :setv img ($1 (:html h) "img")
        :setv image (or (attr img "data-src") (attr img "data-lazy-src") (attr img "src"))
        (assoc h
               "link" (+ (get-app-host) "/redirect/0/"
                         (url-encode-utf8 (re.sub r"^https?://" "ext+jb-gallery://" (:link h))))
               "image" (when image (.replace image "http://" "https://")))))
