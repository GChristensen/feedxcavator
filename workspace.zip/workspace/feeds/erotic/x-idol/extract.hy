(defextractor x-idol-extractor [feed]
  (lfor h (or (parse-pages feed "?paged={n}" 10 :include-source False) [])
        :if (:image h)
        (assoc h "image" (forward-with-url-host (.replace (.strip (:image h)) "http:" "https:") :proxy "default"))))
