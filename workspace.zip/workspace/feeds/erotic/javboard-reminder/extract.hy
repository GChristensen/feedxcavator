(defextractor javboard-reminder-extractor [feed]
  [{"title" "Open JAVBoard"
    "guid" (generate-uuid)
    "link" (redirect-url (+ "ext+jb://main#" (generate-uuid)))}])
