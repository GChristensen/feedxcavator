(defextractor missav-extractor [feed]
  (lfor h (crawl-json "missav/crawl")
        (assoc h "feed" (:category h))))
