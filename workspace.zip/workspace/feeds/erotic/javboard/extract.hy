;; JAVBoard: merges the stored output of the JAV feeds in `params` into one JSON document for the
;; JAVBoard extension, read through the `javboard` handler. The feed itself has no headlines.

(import itertools [groupby])

(defn generate-url-based-id [url]
  (+ "internal:" (md5 (or url (generate-random 16)))))

(defn javboard-preprocess-id [s]
  (when s
    (-> (if (isinstance s str) s (.join "" (map str s)))
        (.replace "FC2 PPV" "FC2-PPV")
        (.replace "FC2PPV-" "FC2-PPV-")
        (.replace "FC2PPV" "FC2-PPV-"))))

(defn extract-onejav-id [s]
  (when s
    (setv mvid (if (in "FC2PPV" s)
                   (.replace s "FC2PPV" "FC2-PPV-")
                   (do (setv found (re-group r"[A-Z]+[0-9]+" (javboard-preprocess-id s) 0))
                       (when found
                         (re.sub r"[A-Z]+" (fn [m] (+ (.group m 0) "-")) found)))))
    (when mvid
      (re.sub r"\s+.*?$" "" mvid))))

(defn extract-jav-movie-id [s]
  (when s
    (setv tentative (re-group r"[A-Z][A-Z\d]*(?:-?[A-Z\d]+)+" (javboard-preprocess-id s) 0))
    (if (and tentative (re.fullmatch r"[A-Z]+[0-9]+" tentative))
        (extract-onejav-id tentative)
        tentative)))

(defn extract-amateur-movie-id [s]
  (when s
    (re-group r"(?:\d+)?[A-Z][A-Z\d]*(?:-[A-Z\d-]+)+" (javboard-preprocess-id s) 0)))

(defn legitimate-item-id? [item-id]
  (bool (and item-id
             (> (len item-id) 4)
             (or (in " " item-id) (in "-" item-id) (re.search r"\d" item-id)))))

(setv TITLE-ID-FEEDS #{"happyjav" "sukebei" "x-idol" "daily jav" "nodejav censored new" "javmost new"}
      TITLE-ID-PREFIXES #("akiba" "javdesu" "javguru" "missav" "pornolab"))

(defn get-javboard-movie-id [h]
  (setv source (:feed h)
        movie-id
        (cond
          (is source None) (generate-url-based-id (:link h))
          (= source "akiba threads") (extract-jav-movie-id (:summary h))
          (or (in source TITLE-ID-FEEDS) (.startswith source TITLE-ID-PREFIXES)) (extract-jav-movie-id (:title h))
          (in source #{"nodejav uncensored new" "nanojav"}) (extract-amateur-movie-id (:title h))
          (= source "onejav") (extract-onejav-id (:title h))
          (in source #{"bestjav" "javmost"}) (extract-amateur-movie-id (:title h))
          True (extract-jav-movie-id (:summary h))))
  (when movie-id
    (setv movie-id (as-> movie-id id
                         (re.sub r"-UNCENSORED.*" "" id)
                         (re.sub r"-REDUCING-MOSAIC.*" "" id)
                         (.replace id "MBR-AA" "MBRAA-")
                         (.replace id "FC2PPV" "FC2-PPV-")
                         (re.sub r"-MR$" "" id))))
  (when (legitimate-item-id? movie-id)
    movie-id))

(defn extract-javboard-feed [feed h]
  (if (.startswith (or (:title feed) "") "missav")
      (:category h)
      (:title feed)))

(defn stored-headlines [suffix]
  "The headlines in the stored JSON output of a feed, with the feed definition."
  (setv feed (find-feed suffix)
        stored (when feed (fetch-feed-output feed)))
  #(feed (if stored (json.loads (:output stored)) [])))

(defn partition-by [key coll]
  (lfor [_ group] (groupby coll key) (list group)))

(defextractor javboard-extractor [feed]
  (setv headlines [])
  (for [suffix (or (:params feed) [])]
    (setv [source items] (stored-headlines suffix))
    (for [item items]
      (setv h (assoc item "feed" (extract-javboard-feed source item)))
      (.append headlines (assoc h "item_id" (or (get-javboard-movie-id h) (generate-url-based-id (:link h)))))))
  (setv headlines (lfor h headlines :if (and (:image h) (not (.startswith (:image h) "@"))) h)
        headlines (->> headlines
                       (filter-history! "javboard")
                       (distinct-by "item_id")
                       (partition-by (fn [h] (:feed h)))))
  (store-object! "javboard" (lfor group headlines (lfor h group (clojure-keys h))))
  (store-object! "javboard-finished-at" (get-day-of-month))
  [])
