;; The latest posts with images of the akiba-online threads in `params`.

(defn akiba-last-page-posts [feed url cookie]
  (setv html (log-fetch-errors (fetch-url url :as "html" :headers (akiba-headers cookie))))
  (when (is html None)
    (return []))
  (setv pages ($ html ".pageNav-main > .pageNav-page > a")
        last-page (+ (:source feed) (or (when pages (attr (get pages -1) "href")) ""))
        html (fetch-url last-page :as "html" :headers (akiba-headers cookie)))
  (lfor h (or (when html (apply-selectors html feed)) [])
        :setv image (akiba-deproxify (:image h))
        :if image
        (assoc h "title" "Akiba post" "image_type" "image/jpeg" "image" image)))

(defextractor akiba-thread-extractor [feed]
  (setv cookie (login-akiba))
  (lfor thread (or (:params feed) [])
        h (akiba-last-page-posts feed (+ (:source feed) (str thread)) cookie)
        h))
