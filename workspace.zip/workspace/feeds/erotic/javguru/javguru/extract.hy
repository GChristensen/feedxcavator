(defextractor javguru-extractor [feed]
  (lfor h (crawl-json "javguru/crawl")
        (assoc h "feed" (:category h))))
