(defextractor javmost-extractor [feed]
  (lfor h (crawl-json "javmost/crawl")
        (assoc h "image" (forward-with-url-host (:image h) :proxy "default"))))
