;; New releases on Yandex Music, in a browser; the release list loads as its container scrolls.

(setv YM-CONTAINER "[class*='BlockEntities_scrollableContainer']"
      YM-SCROLL "(() => {
  const element = document.querySelector(\"[class*='BlockEntities_scrollableContent']\");
  if (element) element.scrollBy(0, 10000);
})()")

(defextractor yandex-music-extractor [feed]
  (with-browser [b]
    (setv page (.open b (:source feed)))
    (.wait page 10)
    (.wait-for page YM-CONTAINER)
    (.click page YM-CONTAINER)
    (for [_ (range 5)]
      (.evaluate page YM-SCROLL)
      (.wait page 1))
    (setv headlines (or (.apply-selectors page) [])))
  (lfor h headlines (assoc h "image_type" "image/jpeg")))
