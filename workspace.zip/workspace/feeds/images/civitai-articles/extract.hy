;; The most bookmarked civitai articles of the month, five pages.

(setv CIVITAI-ARTICLES-URL "https://civitai.red/api/trpc/article.getInfinite"
      CIVITAI-EXCLUDED-TAGS [701 3269 5188 5207 5249 5351 112980 121951 128649 130818 130820 133182 154326 161829
                             163032 198248 279273 306619 415792 426772 543214 586975 128643])

(defn civitai-articles-page [cursor]
  (setv input {"json" {"period" "Month"
                       "periodMode" "published"
                       "sort" "Most Bookmarks"
                       "browsingLevel" 31
                       "excludedTagIds" CIVITAI-EXCLUDED-TAGS
                       "cursor" (or cursor 0)
                       "authed" True}
               "meta" {"values" {"cursor" ["bigint"]}}})
  (fetch-url (+ CIVITAI-ARTICLES-URL "?input=" (url-encode-utf8 (json.dumps input)))
             :as "json" :headers {"user-agent" CHROME-USERAGENT}))

(defextractor civitai-articles-extractor [feed]
  (setv cursor None
        items [])
  (for [_ (range 5)]
    (setv data (get-in (civitai-articles-page cursor) ["result" "data" "json"]))
    (.extend items (or (:items data) []))
    (setv cursor (:nextCursor data)))
  (lfor item items
        :setv cover (:coverImage item)
        :setv author (get-in item ["user" "username"])
        {"title" (:title item)
         "link" (+ "https://civitai.red/articles/" (str (:id item)))
         "guid" (+ "civitai-article-" (str (:id item)))
         "author" author
         "image" (when cover
                   (+ "https://image.civitai.red/xG1nkqKTMzGDvpLrqFT7WA/" (str (:url cover)) "/" (str (:name cover))))
         "summary" (+ "📊 " (str (get-in item ["stats" "collectedCount"] "")) " bookmarks, "
                      (str (get-in item ["stats" "likeCount"] "")) " likes, "
                      (str (get-in item ["stats" "viewCount"] "")) " views | "
                      "By: " (str author) " | Published: " (str (:publishedAt item)))}))
