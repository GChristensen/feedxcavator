;; Deletes the civitai images and videos saved by the civitai feeds, before they are fetched again.
;; The `fetch-civitai` task runs it as its `pre` function; the feed reports it when run by hand.

(import feedxcavator.models [Blob])

(defn purge-civitai []
  "Deletes the stored civitai media and returns a message saying how many."
  (setv targets (list (.filter Blob.objects :source_url__icontains "civitai"))
        failed 0)
  (for [blob targets]
    (try
      (storage.delete-blob blob)
      (except [e Exception]
        (log.write "error" (+ "error deleting civitai media " blob.id ": " (str e)))
        (+= failed 1))))
  (setv message (+ "purged " (str (- (len targets) failed)) " of " (str (len targets)) " civitai images/videos"))
  (log.write "info" message)
  message)

(deftaskfn purge-civitai-media-fn [ctx]
  (purge-civitai))

(defextractor purge-civitai-media [feed]
  (setv message (purge-civitai))
  [{"title" message
    "link" (+ "civitai-purge:" (str (timestamp)))
    "summary" message}])
