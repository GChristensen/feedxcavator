(defextractor modelsociety-extractor [feed]
  (setv base "https://modelsociety.com"
        doc (fetch-url "https://modelsociety.com/images?sort=newest&filter=allimages&cat=female" :as "html"))
  (lfor item ($ doc "div.ms-image-list__item")
        :setv link-path (q1 item "a.ms-image-list__media::attr(href)")
        :if link-path
        :setv image (q1 item "img.ms-image-list-item__image::attr(src)")
        :setv author (text ($1 item "div.ms-image-list__subtitle"))
        {"title" (or (text ($1 item "div.ms-image-list__title")) "Photo")
         "link" (+ base (html-unescape link-path))
         "image" image
         "summary" (+ "<img src=\"" (str image) "\"/><br/>" (or author "Unknown"))}))
