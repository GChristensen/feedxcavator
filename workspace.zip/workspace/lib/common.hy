;; Shared helpers, ported from the `library` module of 3.0.0.

(import json os re subprocess time
        concurrent.futures [ThreadPoolExecutor]
        contextvars
        datetime [date datetime]
        urllib.parse [urlsplit quote-plus]
        django.db [connections]
        feedxcavator [conf fetch storage])

(setv CHROME-USERAGENT "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.166 Safari/537.36")

(defproxy "default" :host "104.193.254.54" :port 52342 :user "squiduser" :password "squidpassword483")
(defproxy "backup" :host "s.thenewone.lol" :port 3145 :scheme "https")


;; text and dates ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn contains-any? [text strings]
  "True when the lower-cased text contains one of the strings."
  (when (and text strings)
    (setv lower (.lower text))
    (any (gfor s strings (in s lower)))))

(defn re-group [pattern s [group 1]]
  "A group of the first match of a regular expression, or None (re-find of 3.0.0)."
  (setv m (when s (re.search pattern s)))
  (when m (.group m group)))

(defn param [feed key [default None]]
  "A value of a feed's `params` map, looked up by its key as written in feed.yaml (`max-pages`).
  The default when `params` is not a map or does not have the key."
  (setv params (:params feed))
  (if (isinstance params dict) (.get params key default) default))

(defn params-path [feed]
  "The `params` list of a feed joined with slashes, for crawlerext arguments."
  (.join "/" (gfor p (or (:params feed) []) (str p))))

(defn secure-url [url]
  "A URL of this server rewritten to its HTTPS address (`secure-hostname` in config.yml)."
  (setv host (get-app-host)
        secure (conf.secure-host))
  (if (and url host secure (.startswith url host))
      (+ secure (cut url (len host) None))
      url))

(defn get-day-of-month []
  (. (date.today) day))

(defn midnight-timestamp []
  "Today's local midnight in milliseconds."
  (int (* 1000 (.timestamp (datetime.combine (date.today) (.time datetime.min))))))


;; RSS and Atom ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn fetch-xml [url #** options]
  "An XML document with namespaces removed: `media:thumbnail` is selected as `thumbnail`,
  `content:encoded` as `encoded`, `dc:creator` as `creator`."
  (setv doc (fetch-url url :as "xml" #** options))
  (when (is-not doc None)
    (.remove-namespaces doc))
  doc)

(defn xml-text [node selector]
  (text (q1 node selector)))

(defn rss-to-headlines [url [image-el "enclosure"] [image-type None] [http-proxy None]]
  "The items of an RSS feed as headlines. `image-el` names the element whose `url` attribute is the image."
  (setv xml (fetch-xml url :headers {"user-agent" CHROME-USERAGENT} :proxy http-proxy))
  (lfor item (q xml "item")
        {"title" (xml-text item "title")
         "link" (xml-text item "link")
         "guid" (xml-text item "link")
         "summary" (xml-text item "description")
         "content" (xml-text item "encoded")
         "author" (or (xml-text item "author") (xml-text item "creator"))
         "category" (xml-text item "category")
         "image" (attr (q1 item image-el) "url")
         "image_type" image-type}))

(defn atom-to-headlines [url [image-el "enclosure"] [image-type None] [http-proxy None]]
  "The entries of an Atom feed as headlines."
  (setv xml (fetch-xml url :headers {"user-agent" CHROME-USERAGENT} :proxy http-proxy))
  (lfor entry (q xml "entry")
        :setv link (attr (q1 entry "link") "href")
        {"title" (xml-text entry "title")
         "link" link
         "guid" link
         "summary" (or (xml-text entry "summary") (xml-text entry "description"))
         "content" (xml-text entry "content")
         "author" (xml-text entry "author name")
         "image" (attr (q1 entry image-el) "url")
         "image_type" image-type}))


;; images ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn image-url [blob]
  "The URL a stored blob is served at."
  (+ (get-app-host) "/image/" blob.id))

(defn _origin [url]
  (try
    (setv parts (urlsplit url))
    #(parts.scheme parts.hostname parts.port)
    (except [Exception] None)))

(defn save-image-blob [url [proxy None] [referer None]]
  "Stores the image at `url` in the blob store (once per URL) and returns its blob, or None."
  (setv existing (storage.find-blob-by-source url))
  (when existing
    (return existing))
  ;; the headers Chrome sends when loading an <img>
  (setv headers {"user-agent" CHROME-USERAGENT
                 "accept" "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
                 "accept-language" "en-US,en;q=0.9"
                 "sec-fetch-dest" "image"
                 "sec-fetch-mode" "no-cors"
                 "sec-fetch-site" (if (and referer (= (_origin referer) (_origin url))) "same-origin" "cross-site")})
  (when referer
    (setv (get headers "referer") referer))
  (setv response (fetch-url url :proxy proxy :headers headers))
  (cond
    (is response None) None
    (not response.body) (do (log.write "error" (+ "Empty image bytes: " url)) None)
    True (storage.store-blob response.body (or (find-header response "content-type") "image/jpeg") url)))

(defn save-image [url [proxy None] [referer None]]
  "Stores the image at `url` and returns the URL it is served at by this server, or None."
  (setv blob (save-image-blob url :proxy proxy :referer referer))
  (when blob (image-url blob)))

(defn forward-with-url-host [resource-url [proxy None] [host None]]
  "A /forward link for a resource, with the root of its own host as the referer."
  (try
    (setv full-url (cond
                     (.startswith resource-url "/") (+ (or host "https://localhost") resource-url)
                     (not (re.match r"^[a-zA-Z][a-zA-Z0-9+.-]*://" resource-url)) (+ "https://" resource-url)
                     True resource-url)
          parts (urlsplit full-url))
    (forward-url resource-url (+ parts.scheme "://" parts.hostname "/") :https True :proxy proxy)
    (except [Exception] None)))


;; the external crawler (crawlerext) ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv CRAWLEREXT-HOME (or (os.environ.get "CRAWLEREXT_HOME")
                          (if (= os.name "nt") "D:/dev/rss/crawlerext" "/home/user/apps/crawlerext")))

(defn _run [command]
  (subprocess.run command :stdout subprocess.PIPE :stderr subprocess.STDOUT
                  :text True :encoding "utf-8" :errors "replace"))

(defn run-crawlerext [params]
  "Runs crawlerext with the arguments in `params` (a string). It prints the name of a file with its
  result; returns the contents of that file and deletes it, or None when the crawler failed."
  (setv args (.split (str params))
        ;; on Windows, what run.cmd does: through cmd.exe the `&` in the arguments would split the command
        command (if (= os.name "nt")
                    [(os.path.join CRAWLEREXT-HOME "venv" "Scripts" "python.exe") (os.path.join CRAWLEREXT-HOME "run.py") #* args]
                    ["/bin/bash" (os.path.join CRAWLEREXT-HOME "run.sh") #* args]))
  (try
    (setv process (_run command))
    (except [e OSError]
      (log.write "error" e)
      (return None)))
  (setv output (.strip (or process.stdout ""))
        lines (lfor line (.splitlines output) :if (.strip line) (.strip line))
        result-file (when lines (get lines -1)))
  (cond
    (!= process.returncode 0)
      (do (log.write "error" (+ "run-crawlerext: run script exited " (str process.returncode) ": " output)) None)
    (not (and result-file (os.path.isfile result-file)))
      (do (log.write "error" (+ "run-crawlerext " (str params) ": no result file in the output: " output)) None)
    True
      (do (with [f (open result-file :encoding "utf-8")]
            (setv contents (.read f)))
          (os.remove result-file)
          contents)))

(defn _crawler-headline [h]
  ;; crawlerext writes Clojure-style keys; the output generators read `image_type`
  (if (and (isinstance h dict) (in "image-type" h))
      (dissoc (assoc h "image_type" (get h "image-type")) "image-type")
      h))

(defn crawl-json [params]
  "The JSON result of a crawlerext run, with headlines normalized. Raises when the crawler failed,
  so the run is recorded as failed (in 3.0.0 reading an empty result threw too)."
  (setv contents (run-crawlerext params))
  (when (is contents None)
    (raise (RuntimeError (+ "crawlerext " (str params) " returned nothing"))))
  (setv data (json.loads contents))
  (if (isinstance data list)
      (lfor h data (_crawler-headline h))
      data))

(defn cf-captcha [site]
  "Solves the Cloudflare challenge of a site in the crawlerext browser profile and waits for it."
  (_run (if (= os.name "nt")
            [(os.path.join CRAWLEREXT-HOME "venv" "Scripts" "python.exe") (os.path.join CRAWLEREXT-HOME "cf-captcha.py") site]
            ["/bin/bash" (os.path.join CRAWLEREXT-HOME "cf-captcha.sh") site]))
  None)


(defn clojure-keys [h]
  "A headline with the key spellings of 3.0.0 (`item-id`, `image-type`), for the JSON read by the
  JAVBoard and T-Board extensions."
  (dfor [k v] (.items h)
        (.get {"item_id" "item-id" "image_type" "image-type"} k k) v))


;; parallel work ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn _in-thread [f x]
  (try
    (f x)
    (finally
      (.close-all connections))))

(defn bounded-pmap [n f coll [timeout 180] [on-error (fn [x e] x)]]
  "Ordered map of `f` on `n` threads. An item whose call raises or takes longer than `timeout`
  seconds gives (on-error item exception) instead. Each call runs in a copy of the current context
  (feed, proxy, cancellation), and closes its database connections."
  (setv pool (ThreadPoolExecutor :max-workers (max 1 (int n))))
  (try
    (setv futures (lfor x coll #(x (.submit pool (. (contextvars.copy-context) run) _in-thread f x))))
    (lfor [x future] futures
          (try
            (.result future :timeout timeout)
            (except [e Exception]
              (on-error x e))))
    (finally
      (.shutdown pool :wait False))))
