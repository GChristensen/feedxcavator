;; Image sites shared by several feeds: 500px, civitai, 35photo.

;; 500px ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv PX500-DEVICE-ID "1a89a915-2b30-4855-8582-dc5e5ce5d4fb"
      PX500-HOST "https://api-neo.500px.com/graphql"
      PX500-MAX-PAGE-SIZE 50)  ; server-enforced cap

(defn px500-headers []
  {"Referer" "https://500px.com/"
   "Origin" "https://500px.com"
   "Content-Type" "application/json"
   "User-Agent" CHROME-USERAGENT
   "x-500px-platform" "Web"
   "Cookie" (+ "x-500px-device-id-prod=" PX500-DEVICE-ID)})

(defn px500-fetch [payload]
  (setv result (fetch-url PX500-HOST :as "json" :headers (px500-headers) :method "post" :payload payload))
  (when (is result None)
    (log.write "error" "px500-fetch: fetch-url returned None"))
  (when (and result (.get result "errors"))
    (log.write "warning" (+ "px500-fetch: GraphQL errors: " (str (get result "errors")))))
  result)

(defn px500-node-urls [node]
  (setv typename (:__typename node))
  (cond
    (in typename ["PhotoGroup" "Gallery"]) (get-in node ["coverPhotos" 0 "urls"])
    (= typename "Video") None
    True (:urls node)))

(defn px500-node->headline [node [channel None]]
  (setv urls (or (px500-node-urls node) {})
        full-image (or (:size_2048 urls) (:size_1024 urls))
        scaled-image (:size_600 urls)
        author (or (:uploader node) (:creator node) {})
        username (:username author))
  (when (and full-image scaled-image)
    {"title" (or (:title node) (:name node))
     "link" (+ "https://500px.com/photo/" (str (:id node)))
     "image" scaled-image
     "author" (:displayName author)
     "summary" (+ "<a href='" full-image "'><img src='" scaled-image "'></a>
                       <br><a href='https://500px.com/" (str username) "'>" (str username) "</a> ["
                  "<a href='" full-image "'>Image</a>"
                  "]" (if channel (+ " / " channel) ""))}))

(defn px500-extract-page [jsn [channel None]]
  (setv data (or (:data jsn) {})
        page (or (next (iter (.values data)) None) {})
        nodes (lfor e (or (:edges page) [])
                    :setv n (:node e)
                    (or (:resource n) n)))
  {"headlines" (keep (fn [n] (px500-node->headline n channel)) nodes)
   "has-next" (get-in page ["pageInfo" "hasNextPage"])
   "end-cursor" (get-in page ["pageInfo" "endCursor"])})

(defn px500-fetch-pages [mk-payload max-pages [channel None]]
  "Fetches up to `max-pages` pages via mk-payload (cursor -> payload). Does not filter by history,
  so callers can merge several sources first."
  (setv after None
        headlines [])
  (for [page (range max-pages)]
    (setv result (px500-extract-page (px500-fetch (mk-payload after)) channel))
    (.extend headlines (get result "headlines"))
    (if (and (get result "has-next") (< (+ page 1) max-pages))
        (do (time.sleep 0.5)
            (setv after (get result "end-cursor")))
        (break)))
  headlines)

(defn px500-extractor [feed mk-payload context [max-pages 1]]
  (setv combined (px500-fetch-pages mk-payload max-pages))
  (when (not combined)
    (log.write "warning" (+ "500px " context " returned nothing")))
  (filter-history! context combined))

(setv PX500-RESOURCE-FIELDS
      "      __typename
      ... on Photo { id title urls { size_600 size_1024 size_2048 } uploader { username displayName } }
      ... on PhotoGroup { id title coverPhotos(first: 5) { urls { size_600 size_1024 size_2048 } } uploader { username displayName } }
      ... on Gallery { id name coverPhotos(first: 5) { urls { size_600 size_1024 size_2048 } } creator { username displayName } }")

(setv PX500-DAILY-DOSE-QUERY
      (+ "query forYouFeed($first: Int!, $after: String, $filter: ForYouFeedFilter, $excludeNsfw: Boolean) {
  forYouFeed(first: $first, after: $after, filter: $filter, excludeNsfw: $excludeNsfw) {
    edges { node { resource {
" PX500-RESOURCE-FIELDS "
    } } }
    pageInfo { hasNextPage endCursor }
  }
}"))

(setv PX500-EDITORS-CHOICE-QUERY
      (+ "query editorsChoices($first: Int!, $after: String, $excludeNsfw: Boolean) {
  editorsChoices(first: $first, after: $after, excludeNsfw: $excludeNsfw) {
    edges { node { resource {
" PX500-RESOURCE-FIELDS "
    } } }
    pageInfo { hasNextPage endCursor }
  }
}"))

(setv PX500-FRESH-QUERY
      (+ "query freshResources($first: Int!, $after: String, $qualityEnabled: Boolean, $excludeNsfw: Boolean) {
  freshResources(first: $first, after: $after, qualityEnabled: $qualityEnabled, excludeNsfw: $excludeNsfw) {
    edges { node {
" PX500-RESOURCE-FIELDS "
    } }
    pageInfo { hasNextPage endCursor }
  }
}"))

(setv PX500-USERID-QUERY
      "query getUserProfile($username: String!) {
  getUser(username: $username) {
    id
    __typename
  }
}")

(setv PX500-USER-QUERY
      "query pageResources($userId: ID!, $first: Int!, $after: String, $resourceTypes: [ResourceType!], $sort: ResourceSortOption = CREATED_AT_DESC, $excludeNsfw: Boolean) {
  pageResources(userId: $userId, first: $first, after: $after, resourceTypes: $resourceTypes, sort: $sort, excludeNsfw: $excludeNsfw) {
    edges { node {
      __typename
      ... on Photo { id title urls { size_600 size_1024 size_2048 } uploader { username displayName } }
      ... on PhotoGroup { id title coverPhotos(first: 5) { urls { size_600 size_1024 size_2048 } } uploader { username displayName } }
      ... on Video { id title coverUrl videoUrl uploader { username displayName } }
    } }
    pageInfo { hasNextPage endCursor }
  }
}")

(defn px500-page-size [feed]
  (min PX500-MAX-PAGE-SIZE (or (param feed "page-size") PX500-MAX-PAGE-SIZE)))

(defn mk-px500-daily-dose-payload [feed]
  (fn [after]
    (json.dumps {"operationName" "forYouFeed"
                 "variables" {"first" (px500-page-size feed)
                              "after" after
                              "filter" "DAILY_DOSE"
                              "excludeNsfw" (bool (param feed "exclude-nsfw"))}
                 "query" PX500-DAILY-DOSE-QUERY})))

(defn mk-px500-editors-choice-payload [feed]
  (fn [after]
    (json.dumps {"operationName" "editorsChoices"
                 "variables" {"first" (px500-page-size feed)
                              "after" after
                              "excludeNsfw" (bool (param feed "exclude-nsfw"))}
                 "query" PX500-EDITORS-CHOICE-QUERY})))

(defn mk-px500-fresh-payload [feed]
  (fn [after]
    (json.dumps {"operationName" "freshResources"
                 "variables" {"first" (px500-page-size feed)
                              "after" after
                              "qualityEnabled" True
                              "excludeNsfw" (bool (param feed "exclude-nsfw"))}
                 "query" PX500-FRESH-QUERY})))

(defn px500-lookup-userid [username]
  (setv jsn (px500-fetch (json.dumps {"operationName" "getUserProfile"
                                      "variables" {"username" username}
                                      "query" PX500-USERID-QUERY})))
  (get-in jsn ["data" "getUser" "id"]))

(defn mk-px500-user-payload [user-id exclude-nsfw]
  (fn [after]
    (json.dumps {"operationName" "pageResources"
                 "variables" {"userId" user-id
                              "first" PX500-MAX-PAGE-SIZE
                              "after" after
                              "resourceTypes" ["PHOTO" "PHOTO_GROUP" "VIDEO"]
                              "sort" "CREATED_AT_DESC"
                              "excludeNsfw" (bool exclude-nsfw)}
                 "query" PX500-USER-QUERY})))

;; [label payload-builder]: the label is shown in each headline's summary. Channels are fetched in
;; this order; of duplicates, the earlier channel's headline is kept.
(setv PX500-DISCOVERY-CATEGORIES
      [["Daily Dose" mk-px500-daily-dose-payload]
       ["Editors' Choice" mk-px500-editors-choice-payload]
       ["Fresh" mk-px500-fresh-payload]])

(defextractor px500-discovery [feed]
  (setv max-pages (int (or (param feed "max-pages") 2))
        headlines [])
  (for [[label mk-payload] PX500-DISCOVERY-CATEGORIES]
    (time.sleep 0.5)
    (.extend headlines (px500-fetch-pages (mk-payload feed) max-pages label)))
  (setv deduped (distinct-by "link" headlines))
  (when (not deduped)
    (log.write "warning" (+ "500px feed:" (:suffix feed) " returned nothing")))
  (filter-history! (+ "feed:" (:suffix feed)) deduped))

(defextractor px500-users [feed]
  (setv headlines [])
  (for [username (or (:params feed) [])]
    (setv user-id (px500-lookup-userid (str username)))
    (time.sleep 1)
    (if user-id
        (.extend headlines (px500-extractor feed (mk-px500-user-payload user-id (param feed "exclude-nsfw"))
                                            (str username) :max-pages 1))
        (log.write "warning" (+ "500px: could not resolve id for " (str username)))))
  headlines)


;; civitai ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv CIVITAI-API-KEY "9cbbdcb5650e67dbea4937741aeb5c7d"
      CIVITAI-STOP-WORDS ["penis" "cock" "testicle" "fellatio"]
      CIVITAI-BASE-URL "https://civitai.red"
      CIVITAI-DEFAULT-PARALLELISM 8)  ; a feed may set `parallelism`

(defn civitai-filter-fn [image]
  (setv prompt (get-in image ["meta" "prompt"]))
  (if prompt
      (not (any (gfor w CIVITAI-STOP-WORDS (in w (.lower prompt)))))
      True))

(defn civitai-fetch-images [start-url max-pages]
  "Follows the nextPage cursor for up to `max-pages` pages and returns all items."
  (setv url start-url
        n 0
        items [])
  (while (and url (< n max-pages))
    (setv response (log-fetch-errors
                     (fetch-url url :as "json" :timeout 30000 :retry 6 :headers {"user-agent" CHROME-USERAGENT})))
    (.extend items (or (:items response) []))
    (setv url (get-in response ["metadata" "nextPage"])
          n (+ n 1)))
  (log.write (+ "civitai: fetched " (str n) " page(s), " (str (len items)) " item(s) total"))
  items)

(defn civitai-video? [img]
  (= (:type img) "video"))

(defn civitai-resources [img]
  "The resource list with models first, e.g. \"foo (model), bar (lora)\"."
  (.join ", " (gfor r (sorted (or (get-in img ["meta" "resources"]) [])
                              :key (fn [r] (if (= (:type r) "model") 0 1)))
                    (+ (str (:name r)) " (" (str (:type r)) ")"))))

(defn civitai-meta [img]
  (+ "Resources: " (civitai-resources img) "<br><br> Prompt: " (str (or (get-in img ["meta" "prompt"]) ""))))

(defn civitai->headline [img]
  (setv h {"id" (:id img)
           "source_url" (:url img)
           "link" (+ CIVITAI-BASE-URL "/images/" (str (:id img)))
           "meta" (civitai-meta img)})
  (if (civitai-video? img)
      (assoc h "video" True "image_type" "video/mp4" "poster_source_url" (get-in img ["thumbnail" "url"]))
      h))

(defn civitai-save-media [h]
  ;; a video is served over HTTPS; the poster is a plain image and stays on the plain host, because
  ;; NewsBlur sends http images through its image proxy, which reaches the feeds host from inside docker
  (setv saved (secure-url (safe-call (save-image (:source_url h))))
        poster-blob (when (and (:video h) (:poster_source_url h))
                      (safe-call (save-image-blob (:poster_source_url h))))
        ;; the "poster" may actually be a video: then there is no poster
        poster (when (and poster-blob (not (.startswith (or poster-blob.content-type "") "video")))
                 (image-url poster-blob)))
  (-> h
      (assoc "image" saved "poster" poster)
      (dissoc "source_url" "poster_source_url")))

;; Videos never put the video URL in the summary: NewsBlur builds the <video> player from the
;; enclosure, and skips an enclosure whose URL already appears in the content. The poster <img>
;; becomes the grid tile's image; without one, NewsBlur loops the video in the tile instead.
(defn civitai-summary [h]
  (cond
    (and (:video h) (:poster h)) (+ "<a href='" (:link h) "'><img src='" (:poster h) "'></a><br><br>" (:meta h))
    (:video h) (+ "<a href='" (:link h) "'>" (:link h) "</a><br><br>" (:meta h))
    True (+ "<a href='" (:link h) "'><img src='" (str (:image h)) "'></a><br><br>" (:meta h))))

(defextractor civitai-extractor [feed]
  (setv parallelism (or (:parallelism feed) CIVITAI-DEFAULT-PARALLELISM)
        images? (get-in feed ["params" "images"])
        url (+ CIVITAI-BASE-URL "/api/v1/images?period=Day&limit=200&nsfw=X"
               (if images? "&type=image" "&type=video")
               "&token=" CIVITAI-API-KEY)
        raw (civitai-fetch-images url (int (or (get-in feed ["params" "pages"]) 1)))
        images (lfor i raw :if (civitai-filter-fn i) i))
  (log.write (+ "civitai: " (str (len images)) " of " (str (len raw)) " item(s) passed the filter"))
  (setv headlines (filter-history! feed (lfor i images (civitai->headline i))))
  (log.write (+ "civitai: " (str (len headlines)) " of " (str (len raw)) " headline(s) passed the history filter"))
  (log.write (+ "civitai: saving " (str (len headlines)) " media file(s), parallelism " (str parallelism)))
  (setv t0 (time.monotonic)
        headlines (bounded-pmap parallelism civitai-save-media headlines))
  (log.write (+ "civitai: media saved in " (str (int (* 1000 (- (time.monotonic) t0)))) " ms, "
                (str (len (lfor h headlines :if (not (:image h)) h))) " failure(s)"))
  (lfor h headlines (assoc h "summary" (civitai-summary h))))


;; pixiv ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv PIXIV-COOKIE "login_ever=yes; p_ab_id=7; p_ab_id_2=9; p_ab_d_id=1363126924; privacy_policy_agreement=6; c_type=42; a_type=0; b_type=1; first_visit_datetime_pc=2023-04-20+22%3A27%3A15; yuid_b=V1BxJGA; cf_clearance=gtwlTz3jE_h_Tge_tZik0HNu39cP5.Joab2Ge1n1HHk-1706738158-1-AU+gxNOvHr/+3yL85fAgAefmS7BriVwvHRwP9Q0mHrkCRkSYQdw56LtzprIdxuzIVIO2+AAGhWYR+mwrQKhAuA4=; privacy_policy_notification=0; PHPSESSID=4113745_XjiM3KwfJkyK2Fwr3apIbXr4x8JKGvO7; QSI_S_ZN_5hF4My7Ad6VNNAi=v:100:0; __cf_bm=q2lnRtYFk_CS.HF06mg0a6inmsP7jr_j8Eej4XJCUSs-1706738154-1-AW4K4S78S9Pkpr3eji8W0p1YtM82QSqE3gXfmFwknPLN5xGcueaXOY/vmWtphdkplM/OzQDfdgeog8X4AvdjyhSX7EG1Jpyh0lKyx+0ZH7z6"
      PIXIV-USERAGENT "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36")

(defn fetch-pixiv-page [url]
  (fetch-url url :as "json" :headers {"User-Agent" PIXIV-USERAGENT "Cookie" PIXIV-COOKIE}))

(defn format-pixiv-headlines [items]
  (lfor i (or items [])
        :setv link (+ "https://www.pixiv.net/en/artworks/" (str (or (:id i) (:illust_id i))))
        :setv image (save-image (:url i) :referer "https://pixiv.net")
        {"title" (:title i)
         "image" image
         "link" link
         "summary" (+ "<a href='" link "'><img src='" (str image) "'></a>")}))

(defextractor pixiv-following-extractor [feed]
  (lfor n (range 1 5)
        h (format-pixiv-headlines
            (get-in (fetch-pixiv-page (+ "https://www.pixiv.net/ajax/follow_latest/illust?mode=all&lang=en&p=" (str n)))
                    ["body" "thumbnails" "illust"]))
        h))

(defextractor pixiv-rankings-extractor [feed]
  (lfor n (range 1 6)
        h (format-pixiv-headlines
            (:contents (fetch-pixiv-page (+ "https://www.pixiv.net/ranking.php?mode=daily&&content=illust&format=json&p="
                                            (str n)))))
        h))

(defextractor pixiv-discovery-extractor [feed]
  ;; ten requests of the same URL: discovery returns different artworks each time
  (lfor n (range 1 11)
        h (distinct-by "link" (format-pixiv-headlines
                                (get-in (fetch-pixiv-page "https://www.pixiv.net/ajax/discovery/artworks?mode=all&limit=60")
                                        ["body" "thumbnails" "illust"])))
        h))


;; 35photo (browser) ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn photo35-parse-items [html]
  (lfor block (cut (re.split r"itemtype=\"https://schema\.org/Photograph\"" (or html "")) 1 None)
        :setv link (re-group r"itemprop=\"url\"\s+content=\"([^\"]+)\"" block)
        :setv creator-block (re-group r"itemprop=\"creator\"(.*)" block)
        :if link
        {"title" (or (re-group r"itemprop=\"name\"\s+content=\"([^\"]+)\"" block) "Photo")
         "link" link
         "image" (re-group r"itemprop=\"contentUrl\"\s+content=\"([^\"]+)\"" block)
         "author" (or (re-group r"itemprop=\"name\"\s+content=\"([^\"]+)\"" creator-block) "Unknown")}))

(defn photo35-page-url [community-id [last-id None]]
  (+ "https://35photo.pro/show_block.php?type=getNextPageData"
     (if community-id "&page=genre&photo_rating=35" "&page=new")
     (if (is last-id None) "" (+ "&lastId=" (str last-id)))
     "&prevNew=true"
     (if community-id (+ "&community_id=" (str community-id)) "")))

(defn sync-xhr-script [url]
  (+ "(() => { const xhr = new XMLHttpRequest(); xhr.open('GET', " (json.dumps url)
     ", false); xhr.send(null); return xhr.responseText; })()"))

(defextractor photo35-extractor [feed]
  (setv community-id (:params feed)
        url (photo35-page-url community-id)
        items [])
  (with-browser [b]
    (setv page (.open b "https://35photo.pro"))
    (.wait page 5)
    (for [_ (range 10)]
      (setv data (json.loads (.evaluate page (sync-xhr-script url))))
      (.extend items (photo35-parse-items (:data data)))
      (setv url (photo35-page-url community-id (:lastId data)))))
  (lfor i items
        {"title" (:title i)
         "link" (:link i)
         "image" (:image i)
         "summary" (+ "<img src=\"" (str (:image i)) "\"/><br/>" (html-unescape (:author i)))}))
