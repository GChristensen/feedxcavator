;; JAV sources shared by several feeds: akiba-online, javlibrary (crawlerext), pornhub (browser).

(import curl-cffi [requests :as curl]
        urllib.parse [unquote-plus])

;; akiba-online ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv AKIBA-LOGIN "shuangxn"
      AKIBA-PASSWORD "mypass4akiba111"
      AKIBA-SESSION-KEY "akiba-online.com-cookie"
      AKIBA-SESSION-TTL 900000)

(defn proxy-for [name]
  "The URL of a named proxy, or None."
  (setv definition (fetch.resolve-proxy name))
  (when definition (fetch.proxy-url definition)))

(defn login-akiba [[proxy "default"]]
  "The Cookie header of a logged-in akiba-online session. The session is reused for 15 minutes."
  (setv login (fetch-object AKIBA-SESSION-KEY))
  (when (and login (:session login) (<= (- (timestamp) (or (:timestamp login) 0)) AKIBA-SESSION-TTL))
    (return (:session login)))
  (setv cookie "")
  (try
    (setv proxy-url (proxy-for proxy)
          session (curl.Session :impersonate "chrome"
                                :proxies (when proxy-url {"http" proxy-url "https" proxy-url}))
          page (.get session "https://www.akiba-online.com/login/login" :timeout 30)
          token (q1 (parse-html page.text) "input[name=\"_xfToken\"]::attr(value)"))
    (.post session "https://www.akiba-online.com/login/login"
           :data {"login" AKIBA-LOGIN
                  "password" AKIBA-PASSWORD
                  "_xfToken" (or token "")
                  "_xfRedirect" "https://www.akiba-online.com/"}
           :allow-redirects False
           :timeout 30)
    (setv cookie (.join "; " (gfor c session.cookies.jar (+ c.name "=" c.value))))
    (except [e Exception]
      (log.write "error" (+ "akiba-online login failed: " (repr e)))))
  (store-object! AKIBA-SESSION-KEY {"session" cookie "timestamp" (timestamp)})
  cookie)

(defn akiba-deproxify [image]
  "The original URL of an image shown through the forum's image proxy."
  (if (and image (in "/proxy/?image=" image))
      (do (setv m (re.fullmatch r".*/proxy/\?image=(.*)&hash=.*" image))
          (when m (unquote-plus (.group m 1))))
      image))

(defn akiba-headers [cookie]
  {"Cookie" cookie "Cache-Control" "no-cache,max-age=0" "Pragma" "no-cache"})

(defn akiba-parse-page [feed url cookie]
  (setv html (log-fetch-errors (fetch-url url :as "html" :headers (akiba-headers cookie))))
  (lfor h (or (when html (apply-selectors html feed)) [])
        (assoc h "image_type" "image/jpeg" "image" (akiba-deproxify (:image h)))))

(defn akiba-assign-image [h cookie]
  "Takes the image and the summary of a thread from its latest posts with images."
  (try
    (setv doc (fetch-url (:link h) :as "html" :headers {"Cookie" cookie})
          posts (lfor p (reversed ($ doc ".message-content article")) :if (not ($ p "blockquote")) p)
          posts-img (lfor p posts :if ($ p ".bbImage") p)
          posts2 (lfor p posts-img
                       :if (not (in "/data/attachments" (or (attr ($1 p ".bbImage") "src") "")))
                       p)
          posts (or posts2 posts-img)
          new-image (when posts ($1 (get posts 0) ".bbImage"))
          all-triggers (lfor p posts-img
                             link (q p ".js-lbImage::attr(href)")
                             :if (in "attachment" link)
                             link)
          all-images (lfor p posts-img
                           src (q p ".bbImage::attr(src)")
                           :if (not (in "static.akiba-online.com" src))
                           src)
          summary (.join "" (gfor i [#* all-triggers #* all-images] (+ "<img src=\"" i "\" border=\"0\" /><br>")))
          new-image-url (when new-image (attr new-image "src")))
    (when new-image-url
      (when (in "static.akiba-online.com" new-image-url)
        (setv trigger-url (attr ($1 (get posts 0) ".LbTrigger") "href"))
        (when (and trigger-url (in "akiba-online.com/attachments" trigger-url))
          (setv new-image-url trigger-url)))
      (setv h (assoc h "image" (akiba-deproxify new-image-url))))
    (assoc h "summary" summary)
    (except [e Exception]
      (log.write "warning" e)
      h)))

(defextractor akiba-extractor [feed]
  (setv cookie (login-akiba))
  (setv headlines
        (lfor forum (or (:params feed) [])
              :setv forum-url (+ (:source feed) (str (if (isinstance forum #(list tuple)) (get forum 0) forum)))
              :setv threads (lfor t [#* (akiba-parse-page feed forum-url cookie)
                                     #* (akiba-parse-page feed (+ forum-url "/page-2") cookie)]
                                  :if (not ($1 (:html t) ".structItem-status--sticky"))
                                  t)
              h (filter-history! forum-url threads)
              h))
  (lfor h headlines (akiba-assign-image h cookie)))


;; javlibrary (crawlerext) ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn javlibrary-crawl [path]
  (lfor h (crawl-json path)
        (assoc h "image" (when (:image h) (re.sub r"s.jpg$" "l.jpg" (:image h))))))

(defextractor javlibrary-extractor-ext [feed]
  (javlibrary-crawl (+ "javlibrary/" (params-path feed))))

(defextractor javlibrary-fav-extractor-ext [feed]
  (javlibrary-crawl (+ "javlibrary/fav/" (params-path feed))))

(defextractor javlibrary-mkr-extractor-ext [feed]
  (javlibrary-crawl (+ "javlibrary/studio/" (params-path feed))))


;; pornhub (browser) ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn extract-pornhub-headlines [b url pages]
  (setv page (.open b "http://example.com"))
  (.wait page 2)
  (setv separator (if (in "?" url) "&page=" "?page=")
        headlines [])
  (for [i (range 1 (+ pages 1))]
    (.goto page (+ url separator (str i)))
    (for [_ (range 2)]
      (.evaluate page "window.scrollBy(0, 2000)")
      (.wait page 1))
    (.extend headlines (or (.apply-selectors page) [])))
  (.close page)
  headlines)

(defextractor pornhub-extractor [feed]
  (setv pages (int (or (get-in feed ["params" "pages"]) 1))
        search-urls (get-in feed ["params" "search"]))
  (with-browser [b]
    (setv raw (if search-urls
                  (distinct-by "link" (mapcat (fn [url] (extract-pornhub-headlines b url pages)) search-urls))
                  (extract-pornhub-headlines b (:source feed) pages))))
  (lfor h raw (assoc h "image" (forward-with-url-host (:image h) :proxy "default"))))
