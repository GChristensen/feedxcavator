;; Extractors shared by several feeds: other feeds, Telegram, Twitter, Reddit.

;; RSS and Atom ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defextractor rss-extractor [feed]
  (rss-to-headlines (:source feed)))

(defextractor physorg-extractor [feed]
  (rss-to-headlines (:source feed) :image-el "thumbnail"))

(defextractor youtube-rss-extractor [feed]
  (atom-to-headlines (:source feed) :image-el "thumbnail"))


;; Telegram ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv TG-FILTER-STRINGS
      ["НАСТОЯЩИЙ МАТЕРИАЛ ПРОИЗВЕДЕН И РАСПРОСТРАНЕН ИНОСТРАННЫМ АГЕНТОМ ГАЛЛЯМОВЫМ АББАСОМ РАДИКОВИЧЕМ. 18+"
       "18+ НАСТОЯЩИЙ МАТЕРИАЛ (ИНФОРМАЦИЯ) ПРОИЗВЕДЕН, РАСПРОСТРАНЕН И (ИЛИ) НАПРАВЛЕН ИНОСТРАННЫМ АГЕНТОМ КАЛИТИНЫМ АНДРЕЕМ СЕРГЕЕВИЧЕМ ЛИБО КАСАЕТСЯ ДЕЯТЕЛЬНОСТИ ИНОСТРАННОГО АГЕНТА КАЛИТИНА АНДРЕЯ СЕРГЕЕВИЧА"])

(defn tg-clean-summary [summary]
  (for [s TG-FILTER-STRINGS]
    (setv summary (.strip (.replace (or summary "") s ""))))
  summary)

(defextractor telegram-extractor [feed]
  (lfor h (or (telegram.get-channel-messages (:params feed)) [])
        (assoc h "summary" (tg-clean-summary (:summary h)))))


;; Twitter (crawlerext) ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defextractor twitter-extractor [feed]
  (crawl-json (get (:params feed) 0)))


;; Reddit (crawlerext) ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defn reddit-subs [feed]
  (.join "/" (gfor s (get-in feed ["params" "subs"] []) (str s))))

(defextractor reddit-news-extractor [feed]
  (lfor h (crawl-json (+ "reddit/news/5/" (reddit-subs feed)))
        (assoc h "author" None "summary" None)))

(defextractor reddit-feed-extractor [feed]
  (setv flair-list (get-in feed ["params" "flairs"])
        flairs (if flair-list
                   ;; form encoding, as java.net.URLEncoder in 3.0.0: a space is "+"
                   (+ "/fl:" (.join "/fl:" (gfor f flair-list (quote-plus (str f)))))
                   ""))
  (lfor h (crawl-json (+ "reddit/feed/5/" (reddit-subs feed) flairs))
        (assoc h "author" None "summary" None)))

(defextractor reddit-images-extractor [feed]
  (lfor h (crawl-json (+ "reddit/images/5/" (reddit-subs feed)))
        (assoc h "author" None)))
