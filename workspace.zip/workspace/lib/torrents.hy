;; Bulletin board trackers (rutracker, pornolab), read by crawlerext.

(defn bb-encode [s]
  ;; form encoding emits "+" for a space, which decodeURIComponent in the extension would keep
  (.replace (quote-plus (str s)) "+" "%20"))

(defn bb-params [params]
  "params is either {forums: [...], topic: ..., ...} or just the forum list."
  (cond
    (isinstance params dict) params
    (isinstance params #(list tuple)) {"forums" params}
    True {"forums" [params]}))

(defn bb-forum-segment [forum flags]
  ;; 1846 -> one page; [1780] -> two pages; [1780, 3] -> three
  (setv [forum-id pages] (if (isinstance forum #(list tuple))
                             [(get forum 0) (if (> (len forum) 1) (get forum 1) 2)]
                             [forum 1]))
  (+ (str forum-id) (if (> pages 1) (+ "-" (str pages)) "") (or flags "")))

(defn bb-crawl-url [site params flags]
  (setv topic (.get params "topic")
        limit (.get params "limit"))
  (.join "/" [site "crawl"
              #* (gfor forum (or (.get params "forums") []) (bb-forum-segment forum flags))
              #* (if topic [(+ "topic=" (bb-encode topic))] [])
              #* (if limit [(+ "limit=" (str limit))] [])]))

(defn bb-crawl [feed params site flags]
  (lfor h (crawl-json (bb-crawl-url site params flags))
        (assoc h "feed" (:title feed))))

(defextractor pornolab-extractor [feed]
  (setv params (bb-params (:params feed))
        category (.get params "category")
        flags (when category (+ ":category=" (bb-encode category))))
  (bb-crawl feed params "pornolab" flags))

(defextractor rt-extractor [feed]
  (setv params (bb-params (:params feed))
        ;; feed-level switches, applied to every forum; :music also gates extlinks in the extension
        music? (if (in "music" params) (get params "music") (in "music" (or (:title feed) "")))
        today? (bool (.get params "today"))
        flags (+ (if music? ":music" "") (if today? ":today" "")))
  (lfor h (bb-crawl feed params "rutracker" flags)
        (assoc h "category" (if music? "music" "movies")
                 "item_id" (+ "internal:" (md5 (:link h))))))


;; Cloudflare challenges, solved in the crawlerext browser profile ;;;;;;;;;;;;;;;

(defextractor rutracker-captcha [feed]
  (cf-captcha "rutracker")
  [])

(defextractor javlibrary-captcha-ext [feed]
  (cf-captcha "javlibrary")
  [])

(defextractor medium-captcha [feed]
  (cf-captcha "medium")
  [])

;; the same as task functions, for `pre` in tasks.yaml
(deftaskfn solve-rutracker-captcha [ctx]
  (cf-captcha "rutracker"))

(deftaskfn solve-javlibrary-captcha [ctx]
  (cf-captcha "javlibrary"))

(deftaskfn solve-medium-captcha [ctx]
  (cf-captcha "medium"))
