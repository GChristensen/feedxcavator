;; YouTube home pages read by crawlerext (feeds youtube and youtube-alter).

(setv YT-TIME-UNITS
      {"minute" 1 "minutes" 1
       "hour" 60 "hours" 60
       "day" 1440 "days" 1440
       "week" 10080 "weeks" 10080
       "month" 43200 "months" 43200
       "year" 525600 "years" 525600
       "минуту" 1 "минуты" 1 "минут" 1
       "час" 60 "часа" 60 "часов" 60
       "день" 1440 "деня" 1440 "дней" 1440
       "неделю" 10080 "недели" 10080 "недель" 10080
       "месяц" 43200 "месяца" 43200 "месяцев" 43200
       "год" 525600 "года" 525600 "лет" 525600})

(defn yt-ago-time [h]
  (when (:summary h)
    (re.sub r"(?i)^.*?views[^\d]+" "" (:summary h))))

(defn yt-ago-time-to-minutes [text]
  "`3 hours ago` in minutes, or 0."
  (setv m (when text (re.search r"(\d+)?\s+([A-Za-zА-Яа-я]+)\s+(?:ago|назад)" text)))
  (if (and m (.group m 1) (.group m 2))
      (* (float (.group m 1)) (.get YT-TIME-UNITS (.group m 2) 0))
      0))

(defn yt-video-id [link]
  (re-group r"[?&]v=([^&]+)" (or link "")))

(defn yt-embed [h]
  (+ (or (:summary h) "") "<iframe src=\"https://youtube.com/embed/" (str (yt-video-id (:link h))) "\"/>"))

(defn yt-author-is-a-bot? [h]
  ;; channel names that end with a year are left out
  (bool (and (:author h) (re.search r"\d{4}$" (.strip (:author h))))))

(defn yt-common [feed headlines]
  (as-> headlines hs
        (filter-history feed hs)
        (lfor h hs :if (:title h) h)))

(defextractor youtube-recent-extractor [feed]
  (setv stop-words (param feed "filter")
        boost (param feed "boost")
        boosted? (fn [h] (or (contains-any? (:title h) boost) (contains-any? (:author h) boost)))
        headlines (yt-common feed (crawl-json "youtube/crawl/profile2"))
        headlines (lfor h headlines
                        :if (not (or (contains-any? (:author h) stop-words) (contains-any? (:title h) stop-words)))
                        h))
  (when stop-words
    (setv headlines (lfor h headlines :if (> 2000 (yt-ago-time-to-minutes (yt-ago-time h))) h)))
  (setv headlines (lfor h headlines :if (not (yt-author-is-a-bot? h)) h)
        headlines (sorted headlines :key (fn [h] (yt-ago-time-to-minutes (:summary h))))
        headlines (sorted headlines :key (fn [h] (if (boosted? h) 0 1))))
  (lfor h (cut headlines 100)
        (assoc h
               "title" (if (boosted? h) (+ "⬆️ " (:title h)) (:title h))
               "summary" (yt-embed h)
               "link" (if (param feed "browser") (+ (:link h) "#alter") (:link h))
               "image" (forward-with-url-host (:image h) :proxy "default"))))

(defn yt-priority [h]
  (setv title (or (:title h) ""))
  (cond
    (re.search r"(?i)teaser" title) 11
    (re.search r"(?i)\bmix\b" title) 12
    (re.search r"(?i)(\bMV\b|\bM/V\b|music\s+video|music\s+clip)" title) 0
    (re.search r"(?i)official\s+video" title) 1
    (re.search r"(?i)full\s+album" title) 2
    (re.search r"(?i)(\bcat|kitty|kitten)" title) 3
    True 10))

(defextractor youtube-plain-extractor [feed]
  (setv headlines (yt-common feed (crawl-json "youtube/crawl/profile1"))
        headlines (lfor h headlines :if (not (yt-author-is-a-bot? h)) h)
        headlines (sorted headlines :key (fn [h] (yt-ago-time-to-minutes (:summary h))))
        headlines (lfor h headlines
                        (assoc h
                               "summary" (yt-embed h)
                               "image" (forward-with-url-host (:image h) :proxy "default"))))
  (sorted headlines :key yt-priority))
