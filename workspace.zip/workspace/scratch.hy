; Run from the console. Sees the live namespace, never changes it.
(print "Hello from Hy")
