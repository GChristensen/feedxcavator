;; The user lists of the image feeds (the `params` list of a feed): add, remove, report.
;; Changes are written to the feed's feed.yaml; the workspace reloads when the file changes.
;; 3.0.0 also resolved vk.com screen names and showed image samples; the vk.com feeds are not
;; carried over and 4.0 has no samples, so the report lists the users only.

(import pathlib [Path]
        feedxcavator [feeddef workspace])

(defn feed-host [feed]
  (get (.split (get (.split (or (:source feed) "") "//") -1) "/") 0))

(defn user-url [feed]
  (setv host (feed-host feed))
  (cond
    (= host "500px.com") "https://500px.com/"
    (= host "www.javlibrary.com") "http://www.javlibrary.com/en/vl_star.php?s="
    (or (.endswith host "twitter.com") (.endswith host "x.com")) "https://twitter.com/"
    (.endswith host "instagram.com") "https://www.instagram.com/"
    True ""))

(defn default-feed [host]
  (cond
    (= host "500px.com") "500px-selected"
    (= host "www.javlibrary.com") "javlibrary-fav"
    (or (.endswith (or host "") "twitter.com") (.endswith (or host "") "x.com")) "twitter-images-japan"
    (.endswith (or host "") "instagram.com") "instagram-japan"))

(defn update-feed-params [suffix f]
  "Rewrites `params` of a feed's feed.yaml with (f params). Returns True when the feed was found."
  (setv info (next (gfor i (.values (. (workspace.get-registry) feeds)) :if (= i.suffix suffix) i) None))
  (when (is info None)
    (return False))
  (setv path (/ (conf.workspace-dir) info.dir "feed.yaml")
        tree (feeddef.load-yaml (.read-text path :encoding "utf-8"))
        params (list (or (.get tree "params") [])))
  (setv (get tree "params") (f params))
  (storage.write-atomic path (feeddef.dump-yaml tree))
  True)

(defhandler :auth add-user-to-feed [feed host user]
  (setv suffix (if (and feed (.strip feed)) feed (default-feed host)))
  (when (and suffix user)
    (update-feed-params suffix (fn [params] (if (in user params) params [#* params user])))
    (text-page "OK")))

;; without :auth, as in 3.0.0: the [remove] links of the report are plain links
(defhandler remove-user-from-feed [feed user]
  (when (and feed user)
    (update-feed-params feed (fn [params] (lfor p params :if (!= (str p) user) p)))
    (text-page "OK")))

(defhandler user-report [feed]
  (setv feed (when feed (find-feed feed)))
  (when feed
    (setv users (or (:params feed) []))
    (html-page
      (+ "<html><head><style>
            body {font-family: Arial, sans-serif;}
            .user {margin-top: 10px}
          </style></head><body>"
         "<p> Total: " (str (len users)) " users.</p>"
         (.join "" (gfor u users
                         (+ "<div class='user'><b><a href='" (user-url feed) (str u) "'>" (html-sanitize (str u)) "</a></b> "
                            "<a href='/handler/remove-user-from-feed?feed=" (:suffix feed) "&user=" (url-encode-utf8 (str u))
                            "'>[remove]</a></div>")))
         "</body></html>"))))
