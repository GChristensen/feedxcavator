;; JSON for the JAVBoard and T-Board browser extensions, built by the javboard and t-board feeds.

(defn board-ready [key]
  (text-page (if (= (get-day-of-month) (fetch-object (+ key "-finished-at"))) "true" "false")))

(defhandler javboard []
  (json-page (or (fetch-object "javboard") [])))

(defhandler javboard-ready []
  (board-ready "javboard"))

(defhandler t-board []
  (json-page (or (fetch-object "t-board") [])))

(defhandler t-board-ready []
  (board-ready "t-board"))


;; akiba ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defhandler search-akiba [keywords]
  ;; YES when the forum search finds anything
  (setv results (fetch-url (+ "https://www.akiba-online.com/search/search?keywords=" (quote-plus (or keywords "")))
                           :headers {"Cookie" (login-akiba)}
                           :as "string"))
  (text-page (if (and results (> (.find results "searchResult") 0)) "YES" "NO")))


;; 500px ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(setv PX500-TOKEN "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIzODkxNzg0IiwiaXNzIjoidSJ9.a-2WaAP2AYWMrfd8fsEJz6JCYR5m4Wdc0xYrYWVd3Hw")

(defhandler px500-full-image [image-id]
  (setv jsn (fetch-url (+ "https://api.500px.com/v1/photos?image_size[]=2048&ids=" (str image-id))
                       :headers {"X-CSRF-Token" PX500-TOKEN} :as "json"))
  (or (get-in jsn ["photos" (str image-id) "images" 0 "url"]) ""))

(defhandler :auth px500-users [arg]
  (setv feed (find-feed "500px-users"))
  (json-page (if feed (or (:params feed) []) [])))
